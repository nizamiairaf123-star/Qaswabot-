"""
optimizer.py — Strategy parameter optimizer
Optuna + Bayesian + RuFlo Portfolio Ranking
Chain: optimizer → walk_forward_validator → ruflo_ranker → deployment_manager

FIXES APPLIED:
- BUG #1: RF weight removed, profit maximized
- BUG #3: WFV filtering — only valid stocks deployed
- BUG #4: Monitoring delay in backtest
- BUG #5: Smart stock blocking
- BUG #7: Per-stock objective (vol/liquidity aware)
- BUG #8: Phase params in PARAM_SPACE
- BUG #9 [ATR-FIX]: _simple_atr() used a windowed Simple TR Mean, which
  silently diverged from the live/backtest canonical ATR (Wilder 1978
  RMA, alpha=1/period, adjust=False) already standardized on in
  strategy_tools.calc_atr() / trade_engine._calculate_atr(). Optimizer
  now imports and reuses strategy_tools.calc_atr() directly — no
  duplicate ATR implementation remains in the optimizer path, and
  optimizer/backtest ATR == live ATR exactly (see test_atr_parity.py).
"""

import logging
import math
import os
import pandas as pd
import numpy as np

logger = logging.getLogger(__name__)

try:
    import optuna
    optuna.logging.set_verbosity(optuna.logging.WARNING)
    HAS_OPTUNA = True
except ImportError:
    HAS_OPTUNA = False

try:
    from skopt import gp_minimize
    from skopt.space import Real, Integer, Categorical
    from skopt.utils import use_named_args
    HAS_SKOPT = True
except ImportError:
    HAS_SKOPT = False

    # Lightweight metadata-only fallbacks so non-optimizer unit tests can
    # import this module in an offline environment. They are NEVER passed to
    # gp_minimize because Bayesian execution explicitly requires skopt.
    class _Dimension:
        def __init__(self, *args, name=None, **kwargs):
            self.name = name
            self.args = args
            self.kwargs = kwargs
    class Real(_Dimension):
        def __init__(self, low, high, name=None, **kwargs):
            super().__init__(low, high, name=name, **kwargs)
            self.low, self.high = low, high
    class Integer(_Dimension):
        def __init__(self, low, high, name=None, **kwargs):
            super().__init__(low, high, name=name, **kwargs)
            self.low, self.high = low, high
    class Categorical(_Dimension):
        def __init__(self, categories, name=None, **kwargs):
            super().__init__(categories, name=name, **kwargs)
            self.categories = categories
    def use_named_args(*args, **kwargs):
        def _decorator(fn):
            return fn
        return _decorator
from utils import load_json, save_json, now_ist, append_log
from config import AUDIT_LOG_FILE, PARAMS
from strategy import calculate_price_dd_during_trade, filter_signals_by_macro_context
from strategy_tools import get_optimizer_signal_generators, calc_atr

OPTIMIZER_RESULTS_FILE = "data/optimizer_results.json"
BLOCKED_STOCKS_FILE = "data/blocked_stocks.json"

# ─────────────────────────────────────────────
# PARAM SPACE — Bayesian search space
# Simple — fewer params = less overfit
# FIX-08: Phase params added to optimization space
# ─────────────────────────────────────────────

PARAM_SPACE = [
    Real(1.5,  5.0,  name="sl_pct"),
    Real(2.0,  8.0,  name="tp1_pct"),
    Real(1.0,  3.0,  name="trail_multiplier"),
    Categorical(["trail", "hybrid", "ratchet"], name="exit_mode"),  # v5.4: exit toolkit — optimizer per-stock decide
    Real(0.25, 2.0, name="profit_lock_pct"),         # v5.4: profit lock (hybrid/ratchet) — lalach-safe guarantee
    Real(0.5,  3.0, name="ratchet_step_pct"),        # v5.4: ratchet step
    Integer(5,  30,  name="ema_fast"),
    Integer(20, 200, name="ema_slow"),
    Integer(7,  21,  name="rsi_period"),
    Integer(25, 40,  name="rsi_oversold"),
    Real(1.2,  2.5,  name="volume_mult"),
    Real(1.0,  3.0,  name="dd_buffer_pct"),
    Integer(1,  7,   name="reentry_cooldown_days"),

    # FIX-09: tool/sector/allocation/risk optimization
    # RR is NOT an optimizer dimension. QASWA locks at exactly 1.8R; trailing is uncapped after lock.
    Integer(10, 60, name="breakout_lookback"),
    Integer(10, 60, name="support_lookback"),
    Integer(14, 30, name="bb_period"),
    Real(1.5, 2.8, name="bb_std"),
    Real(0.0, 1.0, name="sector_strength_weight"),
    Real(0.3, 0.8, name="sector_strength_threshold"),
    Categorical([True, False], name="use_sector_filter"),
    Integer(1, 6, name="max_trades_per_day"),
    Real(1.0, 1.05, name="support_band_mult"),
    Integer(50, 70, name="vwap_rsi_max"),
    Real(0.20, 1.00, name="risk_pct_per_trade"),

    # FIX-08: Phase detection params — now optimizable
    Integer(10, 30, name="phase_ema_fast"),
    Integer(40, 100, name="phase_ema_slow"),
    Real(15, 40, name="phase_adx_threshold"),
    Categorical(["50ema", "100ema", "200ema", "50sma", "200sma", "vwap", "swing_low"], name="support_tool"),
    Integer(55, 75,  name="rsi_overbought"),
    Integer(7,  21,  name="atr_period"),
    Real(1.005, 1.03, name="support_band_pct"),
    Integer(20, 120, name="max_holding_bars"),
    Real(1.0, 3.0, name="wick_multiplier"),  # SL hunt protection — optimized per stock
    Real(0.5, 3.0, name="candle_body_ratio"),  # Candle body size relative to ATR — optimized per stock
    Real(0.5, 3.0, name="candle_wick_ratio"),  # Candle wick size relative to body — optimized per stock
    Integer(1, 5, name="candle_confirmation"),  # Number of candles for pattern confirmation
    Real(1.0, 3.0, name="candle_volume_mult"),  # Volume requirement for candle patterns
    
    # RSI Divergence parameters
    Integer(5, 30, name="divergence_lookback"),  # Bars to look back for divergence
    Real(1.0, 10.0, name="rsi_tolerance"),  # RSI difference tolerance for divergence
    
    # Volume Divergence parameters
    Integer(5, 30, name="volume_lookback"),  # Bars to look back for volume analysis
    Real(0.5, 0.9, name="volume_threshold"),  # Volume decrease threshold
    
    # Candle-Volume parameters
    Real(0.3, 1.0, name="candle_size_threshold"),  # Candle size relative to ATR
    Real(1.0, 3.0, name="volume_spike_threshold"),  # Volume spike multiplier
    
    # MTF Composite parameters
    Integer(1, 10, name="mtf_min_score"),  # Minimum score for MTF composite signal — NO CAP, optimizer decides

    # Rolling-percentile phase-threshold regime calibration (verified method,
    # RegimeFolio methodology, arxiv 2510.14986) — replaces the previously
    # dead/broken fixed-baseline dynamic threshold logic in strategy.py.
    Integer(10, 40,  name="vol_lookback"),
    Integer(120, 504, name="vol_regime_history_days"),
    Real(0.20, 0.40, name="vol_regime_low_quantile"),
    Real(0.60, 0.80, name="vol_regime_high_quantile"),
    Real(0.10, 0.35, name="phase_threshold_adj_range"),
    Real(8.0, 18.0, name="phase_threshold_min"),
    Real(35.0, 55.0, name="phase_threshold_max"),

    # [PHASE-FIX] Connors RSI-2 pullback method params (Connors & Alvarez
    # 2009) — search ranges anchored AROUND the verified method's canonical
    # values (RSI2<10, SMA200 crash filter), tuned per stock:
    Real(5.0, 15.0, name="connors_rsi2_oversold"),
    Integer(150, 250, name="connors_crash_sma_period"),
]

PARAM_NAMES = [p.name for p in PARAM_SPACE]



def build_dynamic_param_space(symbol: str, data: pd.DataFrame) -> tuple:
    """Decision 14 — dynamic Bayesian search range from historical profile."""
    profile = get_stock_profile(symbol, data)
    vol = max(10.0, float(profile.get("volatility", 25.0) or 25.0))
    liq = max(1.0, float(profile.get("liquidity", 1.0) or 1.0))
    trend = abs(float(profile.get("trend", 0.0) or 0.0))

    # Search space boundaries (optimizer-configurable)
    search_bounds = PARAMS.get("optimizer_search_bounds", {
        "fast_high_trend": 30,
        "fast_high_no_trend": 24,
        "slow_high_liquidity": 200,
        "slow_high_no_liquidity": 150,
        "volume_high_low_liquidity": 2.5,
        "volume_high_high_liquidity": 2.0,
        "phase_adx_low_high_vol": 15.0,
        "phase_adx_low_low_vol": 18.0,
        "trend_threshold": 5,
        "liquidity_threshold": 40,
        "vol_threshold": 30,
    })
    
    fast_high = search_bounds["fast_high_trend"] if trend > search_bounds["trend_threshold"] else search_bounds["fast_high_no_trend"]
    slow_high = search_bounds["slow_high_liquidity"] if liq > search_bounds["liquidity_threshold"] else search_bounds["slow_high_no_liquidity"]
    volume_high = search_bounds["volume_high_low_liquidity"] if liq < search_bounds["vol_threshold"] else search_bounds["volume_high_high_liquidity"]
    phase_adx_low = search_bounds["phase_adx_low_high_vol"] if vol > search_bounds["vol_threshold"] else search_bounds["phase_adx_low_low_vol"]

    space = [
        Real(1.0,  3.0, name="trail_multiplier"),
        Categorical(["trail", "hybrid", "ratchet"], name="exit_mode"),
        Real(0.25, 2.0, name="profit_lock_pct"),
        Real(0.5,  3.0, name="ratchet_step_pct"),
        Integer(5,  fast_high,  name="ema_fast"),
        Integer(20, slow_high, name="ema_slow"),
        Integer(7,  21,  name="rsi_period"),
        Integer(25, 40,  name="rsi_oversold"),
        Real(1.2,  volume_high,  name="volume_mult"),
        Real(1.0,  3.0,  name="dd_buffer_pct"),
        Integer(1,  7,   name="reentry_cooldown_days"),
        # RR is fixed by owner exit contract: exactly 1.8R lock, then uncapped trailing.
        Integer(10, 60, name="breakout_lookback"),
        Integer(10, 60, name="support_lookback"),
        Integer(14, 30, name="bb_period"),
        Real(1.5, 2.8, name="bb_std"),
        Real(0.0, 1.0, name="sector_strength_weight"),
        Real(0.3, 0.8, name="sector_strength_threshold"),
        Categorical([True, False], name="use_sector_filter"),
        Integer(1, 6, name="max_trades_per_day"),
        Real(1.0, 1.05, name="support_band_mult"),
        Integer(50, 70, name="vwap_rsi_max"),
        Real(0.20, 1.00, name="risk_pct_per_trade"),
        Integer(10, 30, name="phase_ema_fast"),
        Integer(40, 100, name="phase_ema_slow"),
        Real(phase_adx_low, 40, name="phase_adx_threshold"),
        Categorical(["50ema", "100ema", "200ema", "50sma", "200sma", "vwap", "swing_low"], name="support_tool"),
        Integer(55, 75,  name="rsi_overbought"),
        Integer(7,  21,  name="atr_period"),
        Real(1.005, 1.03, name="support_band_pct"),
        Integer(20, 120, name="max_holding_bars"),
        Real(1.0, 3.0, name="wick_multiplier"),  # SL hunt protection — optimized per stock
        Real(0.5, 3.0, name="candle_body_ratio"),  # Candle body size relative to ATR — optimized per stock
        Real(0.5, 3.0, name="candle_wick_ratio"),  # Candle wick size relative to body — optimized per stock
        Integer(1, 5, name="candle_confirmation"),  # Number of candles for pattern confirmation
        Real(1.0, 3.0, name="candle_volume_mult"),  # Volume requirement for candle patterns
        
        # RSI Divergence parameters
        Integer(5, 30, name="divergence_lookback"),  # Bars to look back for divergence
        Real(1.0, 10.0, name="rsi_tolerance"),  # RSI difference tolerance for divergence
        
        # Volume Divergence parameters
        Integer(5, 30, name="volume_lookback"),  # Bars to look back for volume analysis
        Real(0.5, 0.9, name="volume_threshold"),  # Volume decrease threshold
        
        # Candle-Volume parameters
        Real(0.3, 1.0, name="candle_size_threshold"),  # Candle size relative to ATR
        Real(1.0, 3.0, name="volume_spike_threshold"),  # Volume spike multiplier
        
        # MTF Composite parameters
        Integer(1, 10, name="mtf_min_score"),  # Minimum score for MTF composite signal — NO CAP, optimizer decides
        Integer(10, 40,  name="vol_lookback"),
        Integer(120, 504, name="vol_regime_history_days"),
        Real(0.20, 0.40, name="vol_regime_low_quantile"),
        Real(0.60, 0.80, name="vol_regime_high_quantile"),
        Real(0.10, 0.35, name="phase_threshold_adj_range"),
        Real(8.0, 18.0, name="phase_threshold_min"),
        Real(35.0, 55.0, name="phase_threshold_max"),
        Real(5.0, 15.0, name="connors_rsi2_oversold"),
        Integer(150, 250, name="connors_crash_sma_period"),
    ]
    return space, {p.name: p for p in space}


# ─────────────────────────────────────────────
# SIGNAL GENERATORS
# ─────────────────────────────────────────────

def generate_signals_ema_cross(data: pd.DataFrame, params: dict) -> list:
    fast = data["close"].ewm(span=params["ema_fast"]).mean()
    slow = data["close"].ewm(span=params["ema_slow"]).mean()
    signals = []
    for i in range(1, len(data)):
        if fast.iloc[i] > slow.iloc[i] and fast.iloc[i-1] <= slow.iloc[i-1]:
            signals.append({"idx": i, "action": "BUY"})
        elif fast.iloc[i] < slow.iloc[i] and fast.iloc[i-1] >= slow.iloc[i-1]:
            signals.append({"idx": i, "action": "SELL"})
    return signals


def generate_signals_rsi_ema(data: pd.DataFrame, params: dict) -> list:
    ema   = data["close"].ewm(span=params["ema_slow"]).mean()
    delta = data["close"].diff()
    gain  = delta.clip(lower=0).rolling(params["rsi_period"]).mean()
    loss  = (-delta.clip(upper=0)).rolling(params["rsi_period"]).mean()
    rsi   = 100 - (100 / (1 + gain / (loss + 1e-10)))
    signals = []
    for i in range(1, len(data)):
        if data["close"].iloc[i] > ema.iloc[i] and rsi.iloc[i] < params["rsi_oversold"]:
            signals.append({"idx": i, "action": "BUY"})
    return signals


def generate_signals_breakout(data: pd.DataFrame, params: dict) -> list:
    lookback = int(params.get("breakout_lookback", params.get("support_lookback", 20)))
    signals  = []
    for i in range(lookback, len(data)):
        recent_high = data["high"].iloc[i-lookback:i].max()
        curr_close  = data["close"].iloc[i]
        curr_vol    = data["volume"].iloc[i]
        avg_vol     = data["volume"].iloc[i-lookback:i].mean()
        if curr_close > recent_high and curr_vol > avg_vol * params.get("volume_mult", 1.5):
            signals.append({"idx": i, "action": "BUY"})
    return signals


SIGNAL_GENERATORS = {
    "ema_cross": generate_signals_ema_cross,
    "rsi_ema":   generate_signals_rsi_ema,
    "breakout":  generate_signals_breakout,
}

# FIX-09: expanded optimizable tool library
SIGNAL_GENERATORS.update(get_optimizer_signal_generators())


# ─────────────────────────────────────────────
# FIX-07: PER-STOCK PROFILE + ADAPTIVE WEIGHTS
# Experience trader: volatile stocks need different treatment
# ─────────────────────────────────────────────

def get_stock_profile(symbol: str, data: pd.DataFrame) -> dict:
    """Analyze stock volatility, liquidity, trend strength."""
    returns = data["close"].pct_change()
    volatility = returns.std() * (252 ** 0.5) * 100  # Annualized %

    avg_volume = data["volume"].mean() if "volume" in data.columns else 0
    avg_price  = data["close"].mean()
    liquidity_score = (avg_volume * avg_price) / 1_000_000  # Million Rs/day

    close = data["close"]
    if len(close) >= 20:
        trend = (close.iloc[-1] - close.iloc[-20]) / close.iloc[-20] * 100
    else:
        trend = 0.0

    return {
        "volatility": round(volatility, 2),
        "liquidity": round(liquidity_score, 2),
        "trend": round(trend, 2),
    }


def get_adaptive_weights(profile: dict) -> dict:
    """Continuous objective weights derived from profile features.

    Decision 16/15 runtime intent:
    avoid hard-coded scoring tiers and instead let volatility/liquidity/trend
    continuously reshape what matters more for production quality.
    """
    vol = max(5.0, min(100.0, float(profile.get("volatility", 25.0) or 25.0)))
    liq = max(0.0, float(profile.get("liquidity", 0.0) or 0.0))
    trend = abs(float(profile.get("trend", 0.0) or 0.0))

    vol_norm = min(1.0, vol / 60.0)
    liq_norm = min(1.0, liq / 120.0)
    trend_norm = min(1.0, trend / 20.0)

    _b = PARAMS.get("optimizer_adaptive_weight_base", {})
    pf_weight = float(_b.get("pf_base", 0.24)) + (float(_b.get("pf_vol_slope", 0.14)) * vol_norm)
    wr_weight = float(_b.get("wr_base", 0.18)) + (float(_b.get("wr_vol_slope", 0.08)) * (1.0 - vol_norm))
    ret_weight = float(_b.get("ret_base", 0.22)) + (float(_b.get("ret_liq_slope", 0.14)) * liq_norm)
    rf_weight = float(_b.get("rf_base", 0.16)) + (float(_b.get("rf_trend_slope", 0.08)) * trend_norm)
    sharpe_weight = max(0.08, 1.0 - (pf_weight + wr_weight + ret_weight + rf_weight))

    total = pf_weight + wr_weight + ret_weight + rf_weight + sharpe_weight
    weights = {
        "pf": round(pf_weight / total, 4),
        "wr": round(wr_weight / total, 4),
        "ret": round(ret_weight / total, 4),
        "rf": round(rf_weight / total, 4),
        "sharpe": round(sharpe_weight / total, 4),
    }
    dd_penalty = round(float(_b.get("dd_pen_base", 0.04)) +
                       (float(_b.get("dd_pen_vol_slope", 0.08)) * vol_norm) +
                       (float(_b.get("dd_pen_liq_slope", 0.02)) * (1.0 - liq_norm)), 4)

    return weights, dd_penalty


def _normalize_score_map(score_map: dict) -> dict:
    cleaned = {k: max(0.0, float(v or 0.0)) for k, v in (score_map or {}).items()}
    if not cleaned:
        return {}
    total = sum(cleaned.values())
    if total <= 0:
        equal = round(1.0 / max(len(cleaned), 1), 4)
        return {k: equal for k in cleaned}
    return {k: round(v / total, 4) for k, v in cleaned.items()}


# ─────────────────────────────────────────────
# BACKTEST ENGINE
# FIX-04: Realistic monitoring delay (1 candle = ~3 min for 5-min bars)
# ─────────────────────────────────────────────

def backtest_with_params(data: pd.DataFrame, signal_func, params: dict, symbol: str = None,
                         min_signals: int = 5) -> dict:
    signals = signal_func(data, params)
    # [VERIFIED QUANT METHOD] Optimizer/backtest must reuse the same
    # point-in-time macro gate as live: lagged FII/DII plus sector-primary /
    # regime-fallback hierarchy. This removes look-ahead bias from parameter search.
    signals = filter_signals_by_macro_context(
        data, symbol, signals,
        is_backtest=True,
        params_override=params,
    )
    buy_signals = [s for s in signals if s["action"] == "BUY"]

    # [PHASE-FIX] min_signals ab caller-set hai (default 5 = purana
    # behavior). Per-phase OOS edge measurement ko chhote phases ke liye
    # bhi evaluate karna hota hai — wahan statistical minimum (3) use hota
    # hai, koi arbitrary floor nahi.
    if len(buy_signals) < int(min_signals):
        return None

    cost_pct   = PARAMS["trading_cost_pct"] / 100
    trades     = []
    # Owner engine: validator_reference_capital (capital_drawdown_manager)
    capital    = float(PARAMS["validator_reference_capital"])  # Strict owner value — no fallback
    equity     = []

    # FIX-04: Realistic monitoring delay (1 candle ≈ 3 min gap)
    # Live bot checks every 3 min, so backtest should too
    MONITORING_DELAY_CANDLES = 1

    # [ATR-FIX] Optimizer/backtest ATR must be byte-identical to live ATR.
    # atr_period is constant for this whole backtest_with_params() call (it
    # comes from `params`, not from the per-bar loop), so the canonical
    # Wilder/RMA ATR series (strategy_tools.calc_atr — the same function
    # trade_engine._calculate_atr mirrors for live) is computed ONCE here.
    # calc_atr is causal (ewm(adjust=False)), so atr_series.iloc[j] only
    # ever depends on data up to and including bar j — no look-ahead.
    # This replaces the old _simple_atr() duplicate (windowed Simple TR
    # Mean), which did not match live and has been removed.
    atr_period = int(params.get("atr_period", 14))
    atr_series = calc_atr(data, atr_period)

    for sig in buy_signals:
        entry_idx   = sig["idx"]
        if entry_idx >= len(data) - 1:
            continue

        entry_price = float(data["close"].iloc[entry_idx])
        sl_price    = float(data["low"].iloc[entry_idx])
        if sl_price >= entry_price:
            continue
        # v1.1 EXIT CONTRACT: 1R is the actual entry-to-SL distance; lock is exactly 1.8R
        # lock is followed by uncapped optimizer-selected trailing.
        # v5.4 UNIFIED EXIT TOOLKIT (trail | hybrid | ratchet) —
        # optimizer per-stock exit_mode select karta hai; profit-lock
        # guarantee: profit reach hone ke baad loss me exit nahi (lalach-safe).
        # Backtest == live ek hi engine (exit_engine) — 100% parity.
        from exit_engine import init_state, step
        st = init_state(params, entry_price, sl_price)
        exit_price  = None
        actual_exit_idx = None

        # FIX-04: Start monitoring AFTER delay (simulates real 3-min gap)
        for j in range(entry_idx + MONITORING_DELAY_CANDLES + 1, min(entry_idx + 60, len(data))):
            bar_high  = float(data["high"].iloc[j])
            bar_low   = float(data["low"].iloc[j])
            bar_close = float(data["close"].iloc[j])

            atr_v     = float(atr_series.iloc[j])

            if step(st, bar_high, bar_low, bar_close, atr_v):
                exit_price = st["exit_price"]
                actual_exit_idx = j
                break

        if exit_price is None:
            actual_exit_idx = min(entry_idx + 60, len(data) - 1)
            exit_price = float(data["close"].iloc[actual_exit_idx])

        gross  = (exit_price - entry_price) / entry_price
        net    = gross - cost_pct
        smax   = max(1, int(PARAMS.get("max_slots", 8)))
        capital *= (1 + net / smax)  # [PHD-FIX F1] per-slot share: qty = deployable/smax, isliye portfolio P&L = net% / smax
        equity.append(capital)

        trade_bars = data.iloc[entry_idx:actual_exit_idx + 1]
        price_dd   = calculate_price_dd_during_trade(trade_bars, entry_price)

        trades.append({
            "net_return_pct": round(net * 100, 2),
            "price_dd":       price_dd,
            "entry_idx":      entry_idx,
            "exit_idx":       actual_exit_idx,
            "entry_price":    round(entry_price, 2),
        })

    # [BACKTEST-PARITY] Live-identical parity chain — optimizer in-sample
    # search ab live ke jitne hi filters ke saath score karta hai (trade miss
    # ya live-vs-backtest gap kam). Fail-open: helper error → old behavior.
    try:
        from per_stock_params import get_param
        from parity_engine import run_parity_equity
        _parity = run_parity_equity(
            trades, data, symbol,
            start_capital=float(PARAMS["validator_reference_capital"]),
            max_slots=int(PARAMS.get("max_slots", 8)),
            tp_return_pct=(float(get_param(symbol, "tp1_pct", 3.0) or 3.0)
                           if symbol else float(params.get("tp1_pct", 3.0))),
        )
        if _parity is not None:
            trades = _parity.get("kept_trades", trades)
            capital = _parity["final_capital"]
            equity = _parity["equity"]
    except Exception as e:
        logger.debug(f"backtest_with_params: parity skipped: {type(e).__name__}: {e}")

    if not trades:
        return None

    wins     = [t for t in trades if t["net_return_pct"] > 0]
    losses   = [t for t in trades if t["net_return_pct"] <= 0]
    win_rate = round(len(wins) / len(trades) * 100, 1)
    avg_win  = np.mean([t["net_return_pct"] for t in wins])  if wins   else 0
    avg_loss = np.mean([t["net_return_pct"] for t in losses]) if losses else 0
    pf       = round(abs(avg_win / avg_loss), 2) if avg_loss != 0 else 0

    equity_s = pd.Series(equity)
    roll_max = equity_s.cummax()
    dd_s     = (equity_s - roll_max) / roll_max * 100
    max_dd   = round(float(dd_s.min()), 2)

    price_dd_vals = [t["price_dd"] for t in trades]
    ref_cap = float(PARAMS["validator_reference_capital"])  # Strict owner value — no fallback
    price_max_dd  = round(float(min(price_dd_vals)), 2) if price_dd_vals else 0
    total_return  = round((capital - ref_cap) / ref_cap * 100, 2)
    recovery_f    = round(total_return / abs(max_dd), 2) if max_dd != 0 else 0

    returns   = pd.Series([t["net_return_pct"] for t in trades])
    # [PHD-FIX F7] per-trade Sharpe (standard Sharpe = time-based annualized
    # excess return hai — ye trade-sequence ka mean/std hai; label honest)
    sharpe    = round(float(returns.mean() / (returns.std() + 1e-10)), 2)

    win_rets  = [t["net_return_pct"] for t in trades if t["net_return_pct"] > 0]
    loss_rets = [t["net_return_pct"] for t in trades if t["net_return_pct"] <= 0]
    avg_win   = round(float(np.mean(win_rets)), 2) if win_rets else 0.0
    avg_loss  = round(float(np.mean(loss_rets)), 2) if loss_rets else 0.0

    return {
        "win_rate_pct":           win_rate,
        "total_trades":           len(trades),
        "avg_return_pct":         round(float(np.mean([t["net_return_pct"] for t in trades])), 2),
        "avg_win_return":         avg_win,
        "avg_loss_return":        avg_loss,
        "profit_factor":          pf,
        "recovery_factor":        recovery_f,
        "sharpe":                 sharpe,
        "price_max_drawdown_pct": price_max_dd,
        "portfolio_max_dd_pct":   max_dd,
        "total_return_pct":       total_return,
        "params":                 params,
        "trades":                 trades,
    }


# ─────────────────────────────────────────────
# Phase 3: Deflated Sharpe Ratio (DSR) — Selection Bias Guard
# Bailey & Lopez de Prado (2014)
# ─────────────────────────────────────────────

def _norm_cdf(x: float) -> float:
    """Standard normal CDF Φ(x) — uses scipy if available, else approximation."""
    try:
        from scipy.stats import norm
        return float(norm.cdf(x))
    except Exception:
        # Approximation via error function: Φ(x) = 0.5 * [1 + erf(x/√2)]
        import math
        return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def _norm_ppf(p: float) -> float:
    """Inverse normal CDF Φ^{-1}(p) — uses scipy if available, else approximation."""
    try:
        from scipy.stats import norm
        return float(norm.ppf(p))
    except Exception:
        # Approximation via Acklam's algorithm (simplified)
        # For p close to 0 or 1, return large values
        import math
        if p <= 0.0:
            return -10.0
        if p >= 1.0:
            return 10.0
        # Use inverse error function approximation
        # Φ^{-1}(p) = √2 * erf^{-1}(2p-1)
        # Approximate erf^{-1} via numerical method
        # Simple rational approximation for 0<p<1
        # Using approximation from Peter J. Acklam
        a1 = -3.969683028665376e+01
        a2 = 2.209460984245205e+02
        a3 = -2.759285104469687e+02
        a4 = 1.383577518672690e+02
        a5 = -3.066479806614716e+01
        a6 = 2.506628277459239e+00

        b1 = -5.447609879822406e+01
        b2 = 1.615858368580409e+02
        b3 = -1.556989798598866e+02
        b4 = 6.680131188771972e+01
        b5 = -1.328068155288572e+01

        c1 = -7.784894002430293e-03
        c2 = -3.223964580411365e-01
        c3 = -2.400758277161838e+00
        c4 = -2.549732539343734e+00
        c5 = 4.374664141464968e+00
        c6 = 2.938163982698783e+00

        d1 = 7.784695709041462e-03
        d2 = 3.224671290700398e-01
        d3 = 2.445134137142996e+00
        d4 = 3.754408661907416e+00

        # Define break-points
        plow = 0.02425
        phigh = 1 - plow

        if p < plow:
            # Rational approximation for lower region
            q = math.sqrt(-2 * math.log(p))
            return (((((c1 * q + c2) * q + c3) * q + c4) * q + c5) * q + c6) / ((((d1 * q + d2) * q + d3) * q + d4) * q + 1)
        elif p <= phigh:
            q = p - 0.5
            r = q * q
            return (((((a1 * r + a2) * r + a3) * r + a4) * r + a5) * r + a6) * q / (((((b1 * r + b2) * r + b3) * r + b4) * r + b5) * r + 1)
        else:
            q = math.sqrt(-2 * math.log(1 - p))
            return -(((((c1 * q + c2) * q + c3) * q + c4) * q + c5) * q + c6) / ((((d1 * q + d2) * q + d3) * q + d4) * q + 1)


def calculate_dsr(
    observed_sr: float,
    num_trials: int,
    returns: np.ndarray,
    benchmark_sr: float = 0.0,
) -> float:
    """
    Deflated Sharpe Ratio — Bailey & Lopez de Prado (2014).

    Evaluates probability that observed Sharpe is genuine edge vs statistical luck
    from multiple trials (Selection Bias on Backtest Paths — SBOB).

    Formula:
      Var[SR] = (1 + 0.5*SR^2 - skew*SR + (kurt-3)/4 * SR^2) / (T-1)
      Var0 = 1/(T-1)  (variance under null SR=0)
      E[max SR] = sqrt(Var0) * ((1-γ)*Φ^{-1}(1-1/N) + γ*Φ^{-1}(1-1/(N*e)))
      DSR = Φ( (SR - E[max]) / sqrt(Var[SR]) )

    Args:
        observed_sr: Sharpe ratio from backtest
        num_trials: number of parameter combinations tested (N)
        returns: array of per-trade returns (for skew/kurtosis/T)
        benchmark_sr: benchmark Sharpe (default 0)

    Returns:
        DSR probability 0-1. DSR<0.95 => discard as random noise per spec.

    Reference: https://papers.ssrn.com/sol3/papers.cfm?abstract_id=2460551
    """
    try:
        import math
        import numpy as np

        if returns is None or len(returns) < 10:
            return 0.0

        rets = np.array(returns, dtype=np.float64)
        T = len(rets)

        if T < 10 or num_trials < 1:
            return 0.0

        # Observed SR minus benchmark
        sr = float(observed_sr - benchmark_sr)

        # Skewness and kurtosis
        try:
            from scipy.stats import skew, kurtosis
            skew_val = float(skew(rets))
            kurt_val = float(kurtosis(rets, fisher=False))  # Pearson kurtosis (normal=3)
        except Exception:
            # Fallback manual calculation
            mean = float(np.mean(rets))
            std = float(np.std(rets))
            if std < 1e-12:
                return 0.0
            # Skew
            skew_val = float(np.mean(((rets - mean) / std) ** 3))
            # Kurtosis (Pearson, normal=3)
            kurt_val = float(np.mean(((rets - mean) / std) ** 4))

        # Handle NaN
        if not np.isfinite(skew_val):
            skew_val = 0.0
        if not np.isfinite(kurt_val):
            kurt_val = 3.0

        # Variance of Sharpe estimator
        # Var[SR] = (1 + 0.5*SR^2 - skew*SR + (kurt-3)/4 * SR^2) / (T-1)
        var_sr = (1.0 + 0.5 * sr * sr - skew_val * sr + (kurt_val - 3.0) / 4.0 * sr * sr) / (T - 1)
        if var_sr <= 0:
            var_sr = 1.0 / (T - 1)

        # Variance under null (SR=0)
        var0 = 1.0 / (T - 1)

        # Expected maximum Sharpe under multiple trials
        if num_trials <= 1:
            expected_max = 0.0
        else:
            # Euler-Mascheroni constant
            gamma = 0.5772156649015328606
            e = math.e

            # Φ^{-1}(1 - 1/N)
            try:
                z_n = _norm_ppf(1.0 - 1.0 / num_trials)
            except Exception:
                z_n = 0.0

            # Φ^{-1}(1 - 1/(N*e))
            try:
                z_ne = _norm_ppf(1.0 - 1.0 / (num_trials * e))
            except Exception:
                z_ne = z_n

            expected_max = math.sqrt(var0) * ((1.0 - gamma) * z_n + gamma * z_ne)

        # DSR = Φ( (SR - E[max]) / sqrt(Var[SR]) )
        dsr = _norm_cdf((sr - expected_max) / math.sqrt(var_sr))

        # Clip
        dsr = max(0.0, min(1.0, float(dsr)))
        return dsr

    except Exception as e:
        logger.debug(f"DSR calculation failed: {type(e).__name__}: {e}")
        return 0.0


def calculate_dsr_from_result(result: dict, num_trials: int) -> float:
    """
    Wrapper to calculate DSR from backtest result dict.
    Extracts returns from result['trades'] or result['returns'].
    """
    try:
        if result is None:
            return 0.0

        # Get returns array
        returns = None
        if "trades" in result and result["trades"]:
            returns = np.array([t.get("net_return_pct", 0.0) for t in result["trades"]], dtype=np.float64)
        elif "returns" in result:
            returns = np.array(result["returns"], dtype=np.float64)
        else:
            # Fallback: use total_return as single point? Not enough, return 0
            return 0.0

        observed_sr = float(result.get("sharpe", 0.0) or 0.0)

        return calculate_dsr(observed_sr, num_trials, returns, benchmark_sr=0.0)

    except Exception as e:
        logger.debug(f"DSR from result failed: {e}")
        return 0.0


# ─────────────────────────────────────────────
# FIX-01 + FIX-07: SCORING — NO RF WEIGHT
# Per-stock adaptive weights based on profile
# ─────────────────────────────────────────────

def calculate_institutional_score(result: dict, symbol: str = None,
                                   data: pd.DataFrame = None,
                                   num_trials: int = None) -> float:
    """Decision 16 — weighted production score.

    Single source of truth for optimizer ranking. Uses continuous profile-driven
    weights plus economics, drawdown, recovery and statistical quality.

    Phase 3: DSR gate — if DSR <0.95, score penalized as random noise (SBOB guard).
    """
    if result is None or result.get("total_trades", 0) < 5:
        return 0.0

    pf = float(result.get("profit_factor", 0.0) or 0.0)
    wr = float(result.get("win_rate_pct", 0.0) or 0.0)
    ret = float(result.get("total_return_pct", 0.0) or 0.0)
    dd = abs(float(result.get("portfolio_max_dd_pct", 0.0) or 0.0))
    trades = int(result.get("total_trades", 0) or 0)
    rf = float(result.get("recovery_factor", 0.0) or 0.0)
    sharpe = float(result.get("sharpe", 0.0) or 0.0)
    avg_win = float(result.get("avg_win_return", 0.0) or 0.0)
    avg_loss = abs(float(result.get("avg_loss_return", 0.0) or 0.0))

    # Phase 3: DSR gate — if DSR present in result, check it
    # If DSR <0.95, it's likely random luck from multiple trials, not genuine edge
    dsr = result.get("dsr")
    if dsr is not None:
        try:
            dsr_val = float(dsr)
            if dsr_val < 0.95:
                # Hard gate per spec: DSR<0.95 => discard as random noise
                # Return 0 to ensure this param set is not selected
                return 0.0
        except Exception:
            pass
    else:
        # If num_trials provided and we can compute DSR, compute on the fly
        # This is for cases where DSR not pre-computed in result
        if num_trials is not None and num_trials > 1:
            try:
                # Only compute DSR if we have enough trials to matter (>20)
                # For small trials, DSR gate is less strict
                if num_trials >= 20:
                    computed_dsr = calculate_dsr_from_result(result, num_trials)
                    # Store back into result for audit trail (if dict mutable)
                    try:
                        result["dsr"] = round(computed_dsr, 4)
                        result["dsr_num_trials"] = num_trials
                    except Exception:
                        pass
                    if computed_dsr < 0.95:
                        return 0.0
            except Exception:
                pass

    # Dynamic weights based on stock profile (optimizer-configurable base weights)
    base_weights = PARAMS.get("optimizer_base_weights", {
        "pf": 0.28, "wr": 0.20, "ret": 0.24, "rf": 0.16, "sharpe": 0.12
    })
    dd_penalty_base = PARAMS.get("optimizer_dd_penalty", 0.08)
    
    if symbol and data is not None:
        profile = get_stock_profile(symbol, data)
        weights, dd_penalty = get_adaptive_weights(profile)
    else:
        weights = base_weights
        dd_penalty = dd_penalty_base

    _norm = PARAMS.get("optimizer_norm_baselines", {})
    pf_norm = max(0.0, min(1.0, pf / float(_norm.get("pf", 3.0))))
    wr_norm = max(0.0, min(1.0, (wr - float(_norm.get("wr_center", 35.0))) / float(_norm.get("wr_center", 35.0))))
    ret_norm = max(0.0, min(1.0, ret / float(_norm.get("ret", 60.0))))
    rf_norm = max(0.0, min(1.0, rf / float(_norm.get("rf", 3.0))))
    sharpe_norm = max(0.0, min(1.0, sharpe / float(_norm.get("sharpe", 2.5))))

    expectancy = 0.0
    if avg_loss > 0:
        expectancy = (wr / 100.0 * avg_win) - ((1.0 - wr / 100.0) * avg_loss)
    expectancy_norm = max(0.0, min(1.0, expectancy / float(_norm.get("expectancy", 3.0))))

    weighted_quality = (
        pf_norm * weights["pf"] +
        wr_norm * weights["wr"] +
        ret_norm * weights["ret"] +
        rf_norm * weights["rf"] +
        sharpe_norm * weights["sharpe"]
    )
    _qw = float(_norm.get("quality_weight", 0.90))
    _ew = float(_norm.get("expectancy_weight", 0.10))
    weighted_quality = (weighted_quality * _qw) + (expectancy_norm * _ew)

    _pen = PARAMS.get("optimizer_score_penalties", {})
    score = weighted_quality * 100.0
    score -= dd * (dd_penalty * float(_norm.get("dd_penalty_mult", 10.0)))

    _st = int(_pen.get("small_trades_threshold", 20))
    if trades < _st:
        score *= max(float(_pen.get("small_trades_factor", 0.45)), trades / _st)
    if wr > float(_pen.get("high_wr_threshold", 85.0)):
        score *= float(_pen.get("high_wr_factor", 0.75))
    if dd > float(_pen.get("high_dd_threshold", 20.0)):
        score *= float(_pen.get("high_dd_factor", 0.6))
    if pf < 1.0 or ret <= 0.0 or expectancy <= 0.0:
        score *= float(_pen.get("weak_factor", 0.2))

    return max(0.0, round(float(score), 4))


# ─────────────────────────────────────────────
# BAYESIAN & OPTUNA OPTIMIZATION
# Smart search — converges faster, less overfit
# ─────────────────────────────────────────────

def bayesian_optimize_single(symbol: str, data: pd.DataFrame,
                              signal_func, n_calls: int = 50,
                              persist: bool = True, study_suffix: str = "") -> dict:
    """
    persist=True (default): production per-stock optimization path.
    Uses a persistent SQLite-backed Optuna study keyed on (symbol, signal_func)
    so repeated /optimize runs for the SAME stock can keep improving the same
    search over time. This is fine because each stock already gets its own
    study_name.

    persist=False: walk-forward validation path (walk_forward_validator.py).
    FIX: previously every WFV call passed the literal string "WFV" as
    `symbol`, so ALL stocks and ALL rolling train/test splits for a given
    signal generator shared one persistent, ever-growing Optuna study
    (study_name = "opt_WFV_<gen>", same sqlite file, load_if_exists=True).
    That let the TPE sampler's trial history leak across unrelated stocks
    and across supposedly-independent time windows -- exactly the kind of
    cross-contamination walk-forward validation exists to rule out.
    persist=False forces an in-memory (storage=None), single-use study for
    that one call only -- nothing is written to disk and nothing is loaded
    from a prior call, so every split of every stock is optimized in full
    isolation, as WFV requires. study_suffix lets a caller keep study names
    unique/readable even though nothing persists.
    """
    # Store data reference for per-stock scoring
    _data_ref = data
    _symbol_ref = symbol
    param_space_local, param_space_map = build_dynamic_param_space(symbol, data)
    param_names_local = [p.name for p in param_space_local]

    if HAS_OPTUNA:
        try:
            os.makedirs("data", exist_ok=True)
            def optuna_objective(trial):
                params = {}
                for pname, space_obj in param_space_map.items():
                    if isinstance(space_obj, Real):
                        params[pname] = trial.suggest_float(pname, float(space_obj.low), float(space_obj.high))
                    elif isinstance(space_obj, Integer):
                        params[pname] = trial.suggest_int(pname, int(space_obj.low), int(space_obj.high))
                    elif isinstance(space_obj, Categorical):
                        params[pname] = trial.suggest_categorical(pname, list(space_obj.categories))
                if params["ema_fast"] >= params["ema_slow"]:
                    return 0.0
                if params["phase_ema_fast"] >= params["phase_ema_slow"]:
                    return 0.0
                res = backtest_with_params(data, signal_func, params, symbol=symbol)
                # Phase 3: DSR gate — pass trial count for SBOB correction
                num_trials = trial.number + 1
                # Pre-compute DSR and store in res for audit
                try:
                    dsr_val = calculate_dsr_from_result(res, num_trials)
                    if res is not None:
                        res["dsr"] = round(dsr_val, 4)
                        res["dsr_num_trials"] = num_trials
                except Exception:
                    pass
                return calculate_institutional_score(res, _symbol_ref, _data_ref, num_trials=num_trials)

            study_name = f"opt_{symbol}_{signal_func.__name__}{study_suffix}"
            study = optuna.create_study(
                storage=("sqlite:///data/optuna_study.db" if persist else None),
                study_name=(study_name if persist else None),
                direction="maximize",
                load_if_exists=persist,
                sampler=optuna.samplers.TPESampler(seed=42, multivariate=True, n_startup_trials=10)
            )
            study.optimize(optuna_objective, n_trials=n_calls,
                           n_jobs=int(PARAMS.get("optuna_n_jobs", 4)))
            best_params = study.best_params
            result = backtest_with_params(data, signal_func, best_params, symbol=symbol)
            # Phase 3: Final DSR for best result
            try:
                final_dsr = calculate_dsr_from_result(result, n_calls)
                if result is not None:
                    result["dsr"] = round(final_dsr, 4)
                    result["dsr_num_trials"] = n_calls
                    result["dsr_valid"] = final_dsr >= 0.95
            except Exception:
                pass
            if result and calculate_institutional_score(result, _symbol_ref, _data_ref, num_trials=n_calls) > 0:
                result["params"] = best_params
                result["best_score"] = study.best_value
                append_log(AUDIT_LOG_FILE,
                           f"OPTUNA {symbol}: score={study.best_value:.3f} "
                           f"wr={result['win_rate_pct']}% pf={result['profit_factor']} "
                           f"ret={result['total_return_pct']}% dsr={result.get('dsr','N/A')}")
                return result
            return {}
        except Exception as e:
            append_log(AUDIT_LOG_FILE, f"OPTUNA ERROR {symbol}: {e}. Falling back to skopt.")

    if not HAS_SKOPT:
        append_log(AUDIT_LOG_FILE, f"BAYESIAN ERROR {symbol}: scikit-optimize unavailable; optimization blocked (fail-closed)")
        return {}

    # Track trial count for DSR in skopt path
    _skopt_trial_counter = {"count": 0}

    @use_named_args(param_space_local)
    def objective(**params):
        if params["ema_fast"] >= params["ema_slow"]:
            return 0.0
        if params.get("phase_ema_fast", 10) >= params.get("phase_ema_slow", 50):
            return 0.0
        result = backtest_with_params(data, signal_func, params, symbol=symbol)
        _skopt_trial_counter["count"] += 1
        # Phase 3: DSR gate
        try:
            dsr_val = calculate_dsr_from_result(result, _skopt_trial_counter["count"])
            if result is not None:
                result["dsr"] = round(dsr_val, 4)
                result["dsr_num_trials"] = _skopt_trial_counter["count"]
        except Exception:
            pass
        score = calculate_institutional_score(result, _symbol_ref, _data_ref, num_trials=_skopt_trial_counter["count"])
        return -score

    try:
        res = gp_minimize(
            objective,
            param_space_local,
            n_calls=n_calls,
            random_state=42,
            n_initial_points=10,
            verbose=False,
        )

        best_params = dict(zip(param_names_local, res.x))
        result      = backtest_with_params(data, signal_func, best_params, symbol=symbol)
        # Phase 3: Final DSR
        try:
            final_dsr = calculate_dsr_from_result(result, n_calls)
            if result is not None:
                result["dsr"] = round(final_dsr, 4)
                result["dsr_num_trials"] = n_calls
                result["dsr_valid"] = final_dsr >= 0.95
        except Exception:
            pass

        if result:
            result["params"]     = best_params
            result["best_score"] = -res.fun
            append_log(AUDIT_LOG_FILE,
                       f"BAYESIAN {symbol}: score={-res.fun:.3f} "
                       f"wr={result['win_rate_pct']}% pf={result['profit_factor']} "
                       f"ret={result['total_return_pct']}% dsr={result.get('dsr','N/A')}")
        return result or {}

    except Exception as e:
        append_log(AUDIT_LOG_FILE, f"BAYESIAN ERROR {symbol}: {e}")
        return {}


# ─────────────────────────────────────────────
# ENSEMBLE APPROACH
# Top 3 param sets — average signals
# Reduces overfit dramatically
# ─────────────────────────────────────────────

def build_ensemble(symbol: str, data: pd.DataFrame,
                   signal_func, n_calls: int = 50,
                   top_n: int = 3) -> dict:
    all_results = []
    param_space_local, _ = build_dynamic_param_space(symbol, data)

    if not HAS_SKOPT:
        append_log(AUDIT_LOG_FILE, f"ENSEMBLE ERROR {symbol}: scikit-optimize unavailable; ensemble optimization blocked (fail-closed)")
        return {}

    @use_named_args(param_space_local)
    def objective(**params):
        if params["ema_fast"] >= params["ema_slow"]:
            return 0.0
        result = backtest_with_params(data, signal_func, params, symbol=symbol)
        # Phase 3: DSR gate in ensemble too
        try:
            dsr_val = calculate_dsr_from_result(result, n_calls)
            if result is not None:
                result["dsr"] = round(dsr_val, 4)
        except Exception:
            pass
        score = calculate_institutional_score(result, symbol, data, num_trials=n_calls)
        if score > 0:
            all_results.append({"params": params.copy(), "score": score, "result": result})
        return -score

    try:
        gp_minimize(
            objective,
            param_space_local,
            n_calls=n_calls,
            random_state=42,
            n_initial_points=10,
            verbose=False,
        )
    except Exception as e:
        append_log(AUDIT_LOG_FILE, f"ENSEMBLE ERROR {symbol}: {e}")
        return {}

    if not all_results:
        return {}

    all_results.sort(key=lambda x: x["score"], reverse=True)
    top_results = all_results[:top_n]

    avg_params = {}
    integer_params = {
        "ema_fast", "ema_slow", "rsi_period", "rsi_oversold",
        "reentry_cooldown_days", "breakout_lookback",
        "support_lookback", "bb_period", "max_trades_per_day",
        "phase_ema_fast", "phase_ema_slow", "connors_crash_sma_period",
    }

    for param_name in PARAM_NAMES:
        vals = [r["params"][param_name] for r in top_results]

        if any(isinstance(v, (str, bool)) for v in vals):
            avg_params[param_name] = max(set(vals), key=vals.count)
        else:
            avg_val = float(np.mean(vals))
            if param_name in integer_params:
                avg_params[param_name] = int(round(avg_val))
            else:
                avg_params[param_name] = round(avg_val, 2)

    if avg_params["ema_fast"] >= avg_params["ema_slow"]:
        avg_params["ema_fast"] = max(5, int(avg_params["ema_slow"] * 0.4))
    if avg_params.get("phase_ema_fast", 10) >= avg_params.get("phase_ema_slow", 50):
        avg_params["phase_ema_fast"] = max(10, int(avg_params["phase_ema_slow"] * 0.4))

    ensemble_result = backtest_with_params(data, signal_func, avg_params, symbol=symbol)

    if ensemble_result:
        ensemble_result["params"]          = avg_params
        ensemble_result["ensemble_top_n"]  = top_n
        ensemble_result["individual_top"]  = [r["result"] for r in top_results]
        ensemble_result["best_score"]      = float(np.mean([r["score"] for r in top_results]))

        append_log(AUDIT_LOG_FILE,
                   f"ENSEMBLE {symbol}: top{top_n} avg "
                   f"wr={ensemble_result['win_rate_pct']}% "
                   f"pf={ensemble_result['profit_factor']}")

    return ensemble_result or {}


# ─────────────────────────────────────────────
# PARAMETER STABILITY CHECK
# ─────────────────────────────────────────────

def check_parameter_stability(symbol: str, best_params: dict,
                               data: pd.DataFrame, signal_func) -> dict:
    SENSITIVITY = {
        "sl_pct":           [-1.0, -0.5, +0.5, +1.0],
        "tp1_pct":          [-1.0, -0.5, +0.5, +1.0],
        "trail_multiplier": [-0.5, -0.25, +0.25, +0.5],
        "rsi_oversold":     [-5, -2, +2, +5],
        "ema_fast":         [-5, -2, +2, +5],
        "ema_slow":         [-10, -5, +5, +10],
    }

    baseline = backtest_with_params(data, signal_func, best_params, symbol=symbol)
    if not baseline:
        return {"stable": False, "reason": "Baseline failed"}

    baseline_wr = baseline.get("win_rate_pct", 0)
    variations  = []

    for param_name, deltas in SENSITIVITY.items():
        if param_name not in best_params:
            continue
        base_val = best_params[param_name]

        for delta in deltas:
            test_params = best_params.copy()
            new_val     = base_val + delta

            if param_name in ("sl_pct", "tp1_pct") and new_val <= 0:
                continue
            if param_name == "ema_fast" and new_val <= 0:
                continue
            if param_name == "ema_slow" and new_val <= test_params.get("ema_fast", 0):
                continue

            test_params[param_name] = new_val
            result = backtest_with_params(data, signal_func, test_params, symbol=symbol)
            if result:
                variations.append(abs(result.get("win_rate_pct", 0) - baseline_wr))

    if not variations:
        return {"stable": True, "reason": "No variations", "stability_score": 1.0}

    avg_diff        = round(sum(variations) / len(variations), 1)
    stability_score = round(max(0, 1 - avg_diff / 20), 2)
    is_stable       = avg_diff < 10

    append_log(AUDIT_LOG_FILE,
               f"STABILITY {symbol}: stable={is_stable} avg_diff={avg_diff}%")

    return {
        "symbol":          symbol,
        "stable":          is_stable,
        "stability_score": stability_score,
        "baseline_wr":     baseline_wr,
        "avg_wr_diff":     avg_diff,
        "reason":          "STABLE" if is_stable else f"FRAGILE gap={avg_diff}%",
    }


# ─────────────────────────────────────────────
# FIX-05: SMART STOCK BLOCKING
# Experience trader: only block genuinely bad stocks
# ─────────────────────────────────────────────

def should_block_stock(result: dict) -> bool:
    """Expectancy-Based Blocking (Fix B). Block only when expectancy <= 0."""
    trades = result.get("total_trades", 0)
    if trades < 30:
        return False  # not enough data to judge — don't block on guesswork
    win_rate = result.get("win_rate_pct", 0) / 100.0
    avg_win  = result.get("avg_win_return", 0.0)
    avg_loss = abs(result.get("avg_loss_return", 0.0))
    expectancy = (win_rate * avg_win) - ((1.0 - win_rate) * avg_loss)
    return expectancy <= 0


def categorize_stocks(all_results: dict) -> dict:
    """Categorize stocks into profitable / marginal / blocked based on expectancy."""
    profitable = []
    marginal = []
    blocked = []

    for symbol, result in all_results.items():
        if should_block_stock(result):
            blocked.append(symbol)
        else:
            win_rate = result.get("win_rate_pct", 0) / 100.0
            avg_win  = result.get("avg_win_return", 0.0)
            avg_loss = abs(result.get("avg_loss_return", 0.0))
            expectancy = (win_rate * avg_win) - ((1.0 - win_rate) * avg_loss)
            if expectancy > 0:
                profitable.append(symbol)
            else:
                marginal.append(symbol)

    return {
        "profitable": profitable,
        "marginal": marginal,
        "blocked": blocked,
    }


def _make_phase_filtered_signal_func(base_func, idx_set: set, name: str):
    """Phase-restricted signal func — continuous indicators full series par
    calculate hote hain (no look-ahead), sirf filtered idx ke signals
    return hote hain."""
    def phase_filtered_func(d, params):
        raw_signals = base_func(d, params)  # Continuous timeline calculation
        return [s for s in raw_signals if s.get("idx") in idx_set]
    phase_filtered_func.__name__ = name
    return phase_filtered_func


def _phase_edge_test(net_returns_pct: list, alpha: float = None,
                     min_trades: int = None) -> dict:
    """
    [PHASE-FIX — STATISTICAL EDGE PROOF, no arbitrary thresholds]

    One-sample one-sided t-test: H0 = "is phase me expectancy <= 0"
    (koi edge nahi), H1 = "expectancy > 0" (edge hai).

    Pass conditions (teeno data se derive, koi magic number nahi):
      (a) OOS trades >= min_trades  — t-statistic ke liye df >= 2
          (statistical necessity, strategy choice nahi)
      (b) mean(OOS net returns) > 0
      (c) p-value < alpha — standard one-sided research significance
          convention (config: phase_edge_alpha, default 0.10)

    Small sample apne aap fail hota hai kyunki t-stat sd/sqrt(n) se
    conservative hota hai — isi liye alag se koi "minimum 30 trades" jaisa
    arbitrary rule nahi chahiye.
    """
    alpha = float(alpha) if alpha is not None else float(PARAMS.get("phase_edge_alpha", 0.10))
    min_trades = int(min_trades) if min_trades is not None else int(PARAMS.get("phase_edge_min_oos_trades", 3))

    n = len(net_returns_pct or [])
    if n < min_trades:
        return {"enabled": False, "reason": "insufficient_oos_trades",
                "n": n, "expectancy": None, "p_value": None}

    arr = np.asarray(net_returns_pct, dtype=float)
    mean = float(arr.mean())
    sd = float(arr.std(ddof=1)) if n > 1 else 0.0
    if mean <= 0:
        return {"enabled": False, "reason": "non_positive_expectancy",
                "n": n, "expectancy": round(mean, 3), "p_value": None}
    if sd <= 0:
        return {"enabled": False, "reason": "zero_variance_sample",
                "n": n, "expectancy": round(mean, 3), "p_value": None}

    t_stat = mean / (sd / math.sqrt(n))
    try:
        from scipy import stats as _st
        p_value = float(1.0 - _st.t.cdf(t_stat, df=n - 1))
    except ImportError:
        # scipy absent → standard normal approximation (same convention family)
        p_value = float(0.5 * (1.0 - math.erf(t_stat / math.sqrt(2.0))))

    enabled = bool(p_value < alpha)
    return {
        "enabled": enabled,
        "reason": "edge_statistically_positive" if enabled else "no_statistical_edge",
        "n": n,
        "expectancy": round(mean, 3),
        "p_value": round(p_value, 4),
        "t_stat": round(t_stat, 3),
    }


def optimize_tool_per_phase(symbol: str, data: pd.DataFrame,
                            phase_params: dict = None,
                            n_calls: int = None) -> dict:
    """
    [PHASE-FIX — OPTIMIZATION-DRIVEN PHASE ENABLEMENT]

    Har phase (UPTREND/SIDEWAYS/DOWNTREND) ke liye:

      1. Phase classification — stock ke APNE optimized phase params se
         (phase_ema_fast/slow, phase_adx_threshold...), taaki optimize hote
         waqt ke labels LIVE labels se match karein (pehle defaults se
         classify hota tha → mismatch tha).
      2. Har tool, sirf us phase ke candles par:
         - IS  (chronological first phase_edge_train_fraction): Bayesian
           optimize — persist=False kyunki phase-sets har run me optimized
           params ke saath badal sakte hain (contamination nahi chahiye).
         - OOS (baaki candles): same best params se evaluate — out-of-sample
           trades ke net returns par _phase_edge_test().
      3. Edge proof mila → phase_allow_<phase> = True + best tool + weights.
         Proof NAHI mila → phase_allow_<phase> = False (fail-closed).
         Sample hi insufficient → flag OMIT (measurement nahi hua) —
         strategy gate ka legacy default chalta hai (UPTREND allowed,
         SIDEWAYS/DOWNTREND blocked) jab tak next run measure na kare.

    Return me phase_tool_weights + _phase_edge_metrics (caller params me
    merge karta hai). Purane keys (tool_<phase>, tool_weight_<phase>)
    backward-compatible rakhi gayi hain — capital_manager ka
    get_tool_weight_multiplier bina change ke chalta hai.
    """
    try:
        from strategy import detect_market_phase
        fallback = "ema_cross"
        phase_params = dict(phase_params or {})
        n_calls = int(n_calls) if n_calls is not None else int(PARAMS.get("phase_tool_opt_n_calls", 15))

        slow = int(phase_params.get("phase_ema_slow") or PARAMS.get("phase_ema_slow", 50))
        train_frac = float(PARAMS.get("phase_edge_train_fraction", 0.70))
        alpha = float(PARAMS.get("phase_edge_alpha", 0.10))
        min_oos_trades = int(PARAMS.get("phase_edge_min_oos_trades", 3))
        min_train_candles = int(PARAMS.get("phase_min_train_candles", 50))

        # Classification window: stock ke apne optimized slow EMA se derive
        # (slow*2 candles) — koi arbitrary fixed window nahi.
        window = max(int(slow * 2), 60)
        cutoff = int(len(data) * train_frac)

        # Classify each candle once upfront (live ke jaisa hi: current bar
        # inclusive, sirf past data — no look-ahead)
        phase_map = {}
        for i in range(window, len(data)):
            seg = data.iloc[max(0, i - window):i + 1]
            p = detect_market_phase(seg, symbol, params_override=phase_params)
            if not isinstance(p, str) or p not in ("UPTREND", "SIDEWAYS", "DOWNTREND"):
                p = "SIDEWAYS"
            phase_map.setdefault(p, set()).add(i)

        phase_tools = {}
        phase_weight_map = {}
        phase_edge_metrics = {}

        for phase_name in ("UPTREND", "SIDEWAYS", "DOWNTREND"):
            key_l = phase_name.lower()
            phase_set = phase_map.get(phase_name, set())
            train_set = {i for i in phase_set if i < cutoff}
            oos_set = {i for i in phase_set if i >= cutoff}

            metrics_base = {"train_candles": len(train_set), "oos_candles": len(oos_set)}

            if len(train_set) < min_train_candles:
                # Measurement impossible — flag omit (legacy default active)
                phase_tools[f"tool_{key_l}"] = fallback
                phase_tools[f"tool_weight_{key_l}"] = 0.5
                phase_edge_metrics[phase_name] = {
                    **metrics_base,
                    "enabled": False,
                    "measured": False,
                    "reason": "insufficient_in_sample_candles",
                }
                continue

            best = None
            tool_score_map = {}
            tool_edge_map = {}

            for t_name, t_func in SIGNAL_GENERATORS.items():
                try:
                    train_func = _make_phase_filtered_signal_func(t_func, train_set, f"{t_name}_train")
                    res = bayesian_optimize_single(symbol, data, train_func, n_calls=n_calls,
                                                   persist=False, study_suffix=f"_phase_{key_l}")
                    if not res or res.get("total_trades", 0) < 5:
                        continue

                    oos_func = _make_phase_filtered_signal_func(t_func, oos_set, f"{t_name}_oos")
                    oos = backtest_with_params(data, oos_func, res.get("params", {}),
                                               symbol=symbol, min_signals=min_oos_trades)
                    if not oos:
                        continue

                    sc = calculate_institutional_score(oos, symbol, data)
                    tool_score_map[t_name] = sc

                    edge = _phase_edge_test([t["net_return_pct"] for t in oos.get("trades", [])],
                                            alpha=alpha, min_trades=min_oos_trades)
                    edge["oos_trades"] = oos.get("total_trades", 0)
                    edge["score"] = round(sc, 2)
                    tool_edge_map[t_name] = edge

                    if edge["enabled"] and (best is None or edge["expectancy"] > best["expectancy"]):
                        best = {"tool": t_name, "expectancy": edge["expectancy"],
                                "n": edge["n"], "p_value": edge["p_value"]}
                except (TypeError, ValueError, KeyError, RuntimeError) as e:
                    logger.debug(f"optimize_tool_per_phase: tool {t_name} failed for {symbol}/{phase_name}: {type(e).__name__}")
                    continue

            weights = _normalize_score_map(tool_score_map)
            if best is not None:
                phase_tools[f"tool_{key_l}"] = best["tool"]
                phase_tools[f"tool_weight_{key_l}"] = round(weights.get(best["tool"], 0.5), 4)
                phase_tools[f"phase_allow_{key_l}"] = True
                phase_weight_map[phase_name] = weights
                phase_edge_metrics[phase_name] = {
                    **metrics_base,
                    "enabled": True,
                    "measured": True,
                    "tool": best["tool"],
                    "oos_trades": best["n"],
                    "expectancy_pct": best["expectancy"],
                    "p_value": best["p_value"],
                    "tool_edges": tool_edge_map,
                }
            else:
                # Measure hua, kisi tool me statistical edge nahi → BLOCK
                phase_tools[f"tool_{key_l}"] = fallback
                phase_tools[f"tool_weight_{key_l}"] = 0.5
                phase_tools[f"phase_allow_{key_l}"] = False
                if tool_edge_map:
                    phase_weight_map[phase_name] = weights
                phase_edge_metrics[phase_name] = {
                    **metrics_base,
                    "enabled": False,
                    "measured": True,
                    "reason": "no_tool_with_statistical_edge",
                    "tool_edges": tool_edge_map,
                }

        # [PHD-FIX F2] FDR correction — saare tool×phase tests (per stock)
        # ke p-values pe Benjamini-Hochberg. Koi tool FDR pass nahi karta
        # to phase downgrade (jhoothi edge block — fail-closed).
        try:
            fdr_entries = []
            for ph in ("UPTREND", "SIDEWAYS", "DOWNTREND"):
                em = phase_edge_metrics.get(ph, {})
                for tname, edge in (em.get("tool_edges") or {}).items():
                    if isinstance(edge, dict) and edge.get("enabled") and edge.get("p_value") is not None:
                        fdr_entries.append((ph, tname, edge))
            if fdr_entries:
                bh = _benjamini_hochberg([e[2]["p_value"] for e in fdr_entries])
                passing = {(ph, tname): ok for (ph, tname, _e), ok in zip(fdr_entries, bh)}
                for ph in ("UPTREND", "SIDEWAYS", "DOWNTREND"):
                    kl = ph.lower()
                    em = phase_edge_metrics.get(ph, {})
                    if phase_tools.get(f"phase_allow_{kl}") is not True:
                        for tname, edge in (em.get("tool_edges") or {}).items():
                            if isinstance(edge, dict):
                                edge["fdr_pass"] = bool(passing.get((ph, tname), False))
                        continue
                    best_t = None
                    for tname, edge in (em.get("tool_edges") or {}).items():
                        if not (isinstance(edge, dict) and edge.get("enabled")):
                            continue
                        ok = bool(passing.get((ph, tname), False))
                        edge["fdr_pass"] = ok
                        if ok and (best_t is None
                                   or edge.get("expectancy", -9) > em["tool_edges"][best_t].get("expectancy", -9)):
                            best_t = tname
                    if best_t is None:
                        phase_tools[f"phase_allow_{kl}"] = False
                        phase_tools[f"tools_{kl}"] = []
                        em["enabled"] = False
                        em["fdr_adjusted"] = True
                        em["reason"] = "no_tool_with_statistical_edge (FDR-adjusted — Benjamini-Hochberg 1995)"
                    else:
                        selected_phase_tools = [
                            t for t, edge in (em.get("tool_edges") or {}).items()
                            if isinstance(edge, dict) and edge.get("enabled") and edge.get("fdr_pass") is True
                        ]
                        selected_phase_tools.sort(
                            key=lambda t: float((em.get("tool_edges") or {}).get(t, {}).get("expectancy", 0.0)),
                            reverse=True,
                        )
                        phase_tools[f"tools_{kl}"] = selected_phase_tools or [best_t]
                        phase_tools[f"tool_{kl}"] = best_t  # backward-compatible primary tool
                        em["selected_tools"] = phase_tools[f"tools_{kl}"]
                        em["tool"] = best_t
                        em["fdr_adjusted"] = True
                        em["p_value"] = em["tool_edges"][best_t].get("p_value")
                        em["oos_trades"] = em["tool_edges"][best_t].get("oos_trades")
        except Exception as e:
            logger.debug(f"FDR post-pass failed for {symbol}: {type(e).__name__}: {e}")

        if phase_weight_map:
            phase_tools["phase_tool_weights"] = phase_weight_map
        if phase_edge_metrics:
            phase_tools["_phase_edge_metrics"] = phase_edge_metrics
        append_log(AUDIT_LOG_FILE, f"PHASE TOOLS {symbol}: {phase_tools}")
        return phase_tools
    except (ImportError, RuntimeError, ValueError, TypeError) as e:
        logger.warning(f"_optimize_phase_tools: Failed for {symbol}: {type(e).__name__}: {e}")
        return {}


def _benjamini_hochberg(pvalues: list) -> list:
    """
    [PHD-FIX F2 — VERIFIED: Benjamini & Hochberg 1995] FDR multiple-testing
    correction. Phase gate har stock pe 7 tools × 3 phases = 21 t-tests
    karta hai; bina correction ke chance-se "edge proven" flags bante hain
    (Harvey, Liu & Zhu 2016 data-snooping). BH: sorted p-values pe
    threshold = alpha × rank/m; pehla fail ke baad sab fail.
    Judge parameter — phase_edge_fdr_alpha (0.10) config-driven.
    phase_edge_use_fdr=False → purana per-test alpha behavior (owner toggle).
    Returns bool list (input ke same order me).
    """
    m = len(pvalues)
    if m == 0:
        return []
    if not bool(PARAMS.get("phase_edge_use_fdr", True)):
        alpha = float(PARAMS.get("phase_edge_alpha", 0.10))
        return [p is not None and p < alpha for p in pvalues]
    alpha = float(PARAMS.get("phase_edge_fdr_alpha", 0.10))
    order = sorted(range(m), key=lambda i: pvalues[i] if pvalues[i] is not None else 2.0)
    sig = [False] * m
    for rank, idx in enumerate(order, start=1):
        p = pvalues[idx]
        if p is None:
            continue
        if p <= alpha * rank / m:
            sig[idx] = True
        else:
            break  # sorted ascending — aage wale bhi fail
    return sig


# ─────────────────────────────────────────────
# SINGLE STOCK OPTIMIZER
# Bayesian + Ensemble + Stability check
# PER-STOCK TOOLSET SELECTION (1..11 tools)
# ─────────────────────────────────────────────

def _make_composite_signal_func(selected_tools, vote_threshold=1):
    """Create a deterministic signal function for an optimizer-selected toolset."""
    selected = [t for t in (selected_tools or []) if t in SIGNAL_GENERATORS]
    threshold = max(1, min(int(vote_threshold or 1), len(selected) or 1))

    def composite(data, params):
        if not selected:
            return []
        votes = {}
        for name in selected:
            for sig in SIGNAL_GENERATORS[name](data, params):
                idx = sig.get("idx")
                if idx is not None:
                    votes[idx] = votes.get(idx, 0) + 1
        return [{"idx": i, "action": "BUY", "tool_count": votes[i]}
                for i in sorted(votes) if votes[i] >= threshold]

    composite.__name__ = "toolset_" + "_".join(selected)
    return composite


def _select_per_stock_toolset(symbol: str, data: pd.DataFrame, all_results: dict, phase_edges: dict) -> dict:
    """Select a robust per-stock subset from the full 11-tool library.

    Selection is staged rather than brute-forcing all 2^11-1 subsets: first
    establish individually evidenced candidates, then greedily test additions
    using the same backtest/exit engine.  At each step the vote threshold is
    also searched from 1..N.  This permits any non-empty subset size (1..11)
    while avoiding an exponential 2,047-combination search per stock.

    Phase OOS/FDR evidence is used as an eligibility signal when available; it
    is not a blanket requirement when the phase measurement itself is absent.
    Safety/compliance gates are outside this selector and remain mandatory.
    """
    available = [n for n in SIGNAL_GENERATORS if n in all_results]
    if not available:
        return {"selected_tools": [], "tool_vote_threshold": 1}

    evidenced = []
    phase_measured = False
    for phase in ("UPTREND", "SIDEWAYS", "DOWNTREND"):
        em = phase_edges.get(phase, {}) if isinstance(phase_edges, dict) else {}
        if em.get("measured"):
            phase_measured = True
        for name, edge in (em.get("tool_edges") or {}).items():
            if name not in available or not isinstance(edge, dict) or not edge.get("enabled"):
                continue
            if edge.get("fdr_pass") is False:
                continue
            if PARAMS.get("phase_edge_use_fdr", True) and edge.get("fdr_pass") is not True:
                continue
            if name not in evidenced:
                evidenced.append(name)

    candidate_pool = evidenced if evidenced else available
    # Keep the strongest individually validated candidates first.
    candidate_pool.sort(key=lambda n: float(all_results[n].get("score", 0.0)), reverse=True)
    base_params = dict(all_results[candidate_pool[0]].get("result", {}).get("params", {}) or {})
    if not base_params:
        return {"selected_tools": [candidate_pool[0]], "tool_vote_threshold": 1,
                "selection_method": "best_individual_tool_fallback"}

    def evaluate(tool_names):
        best = None
        for threshold in range(1, len(tool_names) + 1):
            fn = _make_composite_signal_func(tool_names, threshold)
            res = backtest_with_params(data, fn, base_params, symbol=symbol)
            if not res or int(res.get("total_trades", 0)) < 5:
                continue
            score = calculate_institutional_score(res, symbol, data)
            if best is None or score > best["score"]:
                best = {"score": float(score), "threshold": threshold, "result": res}
        return best

    selected = [candidate_pool[0]]
    current = evaluate(selected)
    if current is None:
        current = {"score": float(all_results[selected[0]].get("score", 0.0)), "threshold": 1,
                   "result": all_results[selected[0]].get("result", {})}

    remaining = [n for n in candidate_pool if n not in selected]
    while remaining and len(selected) < len(SIGNAL_GENERATORS):
        best_add = None
        for name in remaining:
            trial = evaluate(selected + [name])
            if trial is None:
                continue
            if best_add is None or trial["score"] > best_add["score"]:
                best_add = {"name": name, **trial}
        # Require a real improvement; otherwise adding tools is noise/overfit.
        if best_add is None or best_add["score"] <= current["score"]:
            break
        selected.append(best_add["name"])
        current = {k: v for k, v in best_add.items() if k != "name"}
        remaining.remove(best_add["name"])

    # If phase evidence was not measurable, retain the best individual tool
    # rather than manufacturing a large ensemble from unavailable evidence.
    method = "staged_subset_search_oos_fdr" if phase_measured else "staged_subset_search"
    return {
        "selected_tools": selected,
        "tool_vote_threshold": int(current.get("threshold", 1)),
        "selection_method": method,
        "subset_score": round(float(current.get("score", 0.0)), 4),
        "subset_search_evaluated": True,
    }


def optimize_single_stock(symbol: str, data: pd.DataFrame = None) -> dict:
    if data is None:
        data = _fetch_data(symbol)

    if data is None or len(data) < 100:
        return {"symbol": symbol, "valid": False, "error": "Insufficient data"}

    best_result  = None
    best_score   = -999
    tool_scores  = {}
    all_results  = {}  # Store all valid results for multiple combo

    for gen_name, gen_func in SIGNAL_GENERATORS.items():
        # Primary: Optuna/Bayesian optimizer.
        # Ensemble remains as fallback for robustness.
        result = bayesian_optimize_single(symbol, data, gen_func, n_calls=50)

        if not result or result.get("total_trades", 0) < 5:
            result = build_ensemble(symbol, data, gen_func, n_calls=50, top_n=3)

        if not result or result.get("total_trades", 0) < 5:
            continue

        score = calculate_institutional_score(result, symbol, data)
        tool_scores[gen_name] = score
        all_results[gen_name] = {"result": result, "score": score}

        if score > best_score:
            best_score  = score
            best_result = result.copy()
            best_result["signal_generator"] = gen_name
            best_result["symbol"]           = symbol
            best_result["valid"]            = True
            best_result["optimized_at"]     = now_ist().isoformat()

    if best_result is None:
        return {"symbol": symbol, "valid": False, "error": "No valid result"}

    # ── PER-STOCK TOOLSET ──
    # Phase optimization is the evidence source; no fixed TOP-N cap.
    provisional_phase = optimize_tool_per_phase(
        symbol, data, phase_params=best_result.get("params", {})
    )
    phase_edges = provisional_phase.get("_phase_edge_metrics", {}) if provisional_phase else {}
    toolset = _select_per_stock_toolset(symbol, data, all_results, phase_edges)
    if not toolset.get("selected_tools"):
        return {"symbol": symbol, "valid": False, "error": "No optimizer-selected toolset"}

    best_result["selected_tools"] = toolset["selected_tools"]
    best_result["tool_vote_threshold"] = toolset["tool_vote_threshold"]
    best_result["toolset_selection_method"] = toolset["selection_method"]
    best_result["toolset_count"] = len(toolset["selected_tools"])
    best_result["params"]["selected_tools"] = list(toolset["selected_tools"])
    best_result["params"]["tool_vote_threshold"] = int(toolset["tool_vote_threshold"])
    best_result["top_combos"] = []  # Compatibility only; TOP-3 is no longer a criterion.
    best_result["combo_count"] = len(toolset["selected_tools"])

    gen_name  = best_result.get("signal_generator", "ema_cross")
    gen_func  = SIGNAL_GENERATORS.get(gen_name, generate_signals_ema_cross)
    stability = check_parameter_stability(
        symbol, best_result["params"], data, gen_func
    )
    best_result["stability"]     = stability
    best_result["params_stable"] = stability.get("stable", False)

    profile = get_stock_profile(symbol, data)
    best_result["stock_profile"] = profile
    best_result["weighted_production_score"] = round(best_score, 4)
    best_result["tool_scores"] = tool_scores
    best_result["tool_weights"] = _normalize_score_map(tool_scores)

    # [PHASE-FIX] Per-phase optimization ab stock ke APNE optimized phase
    # params se classify karta hai (live ke jaisa), aur har phase ka
    # statistical edge proof + enable/disable flag nikalta hai.
    phase_tools = provisional_phase
    if phase_tools and "params" in best_result:
        edge_metrics = phase_tools.pop("_phase_edge_metrics", None)
        best_result["params"].update({k: v for k, v in phase_tools.items() if k != "phase_tool_weights"})
        if phase_tools.get("phase_tool_weights"):
            best_result["phase_tool_weights"] = phase_tools.get("phase_tool_weights")
        if edge_metrics:
            best_result["phase_edge_metrics"] = edge_metrics

    append_log(AUDIT_LOG_FILE,
               f"OPTIMIZER {symbol}: wr={best_result['win_rate_pct']}% "
               f"pf={best_result['profit_factor']} "
               f"ret={best_result['total_return_pct']}% "
               f"stable={best_result['params_stable']} "
               f"gen={best_result['signal_generator']} "
               f"combos={best_result['combo_count']} "
               f"score={best_result['weighted_production_score']} "
               f"vol={profile['volatility']}% liq={profile['liquidity']}M")
    return best_result


# ─────────────────────────────────────────────
# FULL UNIVERSE OPTIMIZER
# FIX-03: WFV filtering — only valid stocks deployed
# RuFlo: Portfolio ranking of valid stocks
# ─────────────────────────────────────────────

def optimize_full_universe(symbols: list = None) -> dict:
    if symbols is None:
        from stock_selector import load_halal_symbols
        symbols = load_halal_symbols()

    all_results = {}
    all_params  = {}

    append_log(AUDIT_LOG_FILE, f"OPTIMIZER START: {len(symbols)} stocks")
    try:
        from workflow_manager import start_optimization_cycle, record_data_collection, record_feature_calculation
        start_optimization_cycle(total_symbols=len(symbols), trigger="optimize_full_universe")
        record_data_collection(source="optimizer_historical_fetch", total_symbols=len(symbols))
        record_feature_calculation(source="optimizer_signal_feature_pipeline", total_symbols=len(symbols))
    except Exception as e:
        append_log(AUDIT_LOG_FILE, f"WORKFLOW MARK ERROR OPTIMIZER START: {e}")

    for symbol in symbols:
        result = optimize_single_stock(symbol)
        if result.get("valid"):
            all_results[symbol] = result
            all_params[symbol]  = result.get("params", {})
            all_params[symbol]["signal_generator"] = result.get("signal_generator")
            all_params[symbol]["selected_tools"] = list(result.get("selected_tools") or [])
            all_params[symbol]["tool_vote_threshold"] = int(result.get("tool_vote_threshold", 1))
            for _ph, _tools in (result.get("phase_selected_tools") or {}).items():
                all_params[symbol][f"tools_{str(_ph).lower()}"] = list(_tools or [])
            # FIX-08: Store phase params
            for p in ("phase_ema_fast", "phase_ema_slow", "phase_adx_threshold"):
                if p in result.get("params", {}):
                    all_params[symbol][p] = result["params"][p]

    # Walk-forward validation
    wfv_results = {}
    for symbol, result in all_results.items():
        data = _fetch_data(symbol)
        if data is not None and len(data) >= 200:
            gen_name = result.get("signal_generator", "ema_cross")
            selected = result.get("selected_tools") or result.get("params", {}).get("selected_tools") or [gen_name]
            threshold = int(result.get("tool_vote_threshold", result.get("params", {}).get("tool_vote_threshold", 1)) or 1)
            gen_func = _make_composite_signal_func(selected, threshold)
            from walk_forward_validator import run_walk_forward
            opt_score = result.get("best_score", 0)
            # Phase 2: Purged & Embargoed CV — 5-day purge + 5-day embargo per spec
            wfv = run_walk_forward(
                symbol, data, gen_func,
                {k: [v] for k, v in result.get("params", {}).items() if k not in ("selected_tools", "tool_vote_threshold")},
                opt_score=opt_score,
                purge_gap=5,
                embargo=5,
                enable_purged_cv=True,
            )
            wfv_results[symbol] = wfv
    try:
        from walk_forward_validator import save_wfv_results
        save_wfv_results(wfv_results)
    except (ImportError, RuntimeError, OSError) as e:
        logger.warning(f"optimize_full_universe: Save WFV results failed: {type(e).__name__}: {e}")

    # FIX-03: Filter deployment by WFV validity
    deployable_params = {}
    overfit_stocks = []

    for symbol, result in all_results.items():
        wfv = wfv_results.get(symbol, {})
        if wfv.get("valid"):
            deployable_params[symbol] = all_params[symbol]
            append_log(AUDIT_LOG_FILE,
                       f"DEPLOY ✅ {symbol}: wfv_gap={wfv.get('gap')}%")
        else:
            overfit_stocks.append({
                "symbol": symbol,
                "reason": wfv.get("reason", "Unknown"),
                "gap": wfv.get("gap", "N/A"),
            })
            append_log(AUDIT_LOG_FILE,
                       f"BLOCK ❌ {symbol}: {wfv.get('reason')}")

    # FIX-05: Smart stock categorization
    categories = categorize_stocks(all_results)

    # RuFlo: Portfolio ranking of deployable stocks
    ruflo_ranking = []
    try:
        from ruflo_ranker import rank_portfolio
        ruflo_ranking = rank_portfolio(deployable_params, all_results, wfv_results)
        append_log(AUDIT_LOG_FILE,
                   f"RUFLO: Ranked {len(ruflo_ranking)} deployable stocks")
    except ImportError:
        append_log(AUDIT_LOG_FILE, "RUFLO: ruflo_ranker not available, skipping ranking")
    except Exception as e:
        append_log(AUDIT_LOG_FILE, f"RUFLO ERROR: {e}")

    # Save full results
    output = {
        "run_date":  now_ist().isoformat(),
        "total":     len(symbols),
        "optimized": len(all_results),
        "deployable": len(deployable_params),
        "overfit": len(overfit_stocks),
        "results":   all_results,
        "per_stock": deployable_params,  # FIX-03: Only deployable params
        "all_params": all_params,         # Keep all for reference
        "wfv_results": wfv_results,
        "overfit_stocks": overfit_stocks,
        "categories": categories,
        "ruflo_ranking": ruflo_ranking,
    }
    save_json(OPTIMIZER_RESULTS_FILE, output)

    # FIX-05: Save blocked stocks
    if categories["blocked"]:
        save_json(BLOCKED_STOCKS_FILE, {
            "updated_at": now_ist().isoformat(),
            "blocked": categories["blocked"],
            "marginal": categories["marginal"],
            "reason": "extremely_poor_performance",
        })

    valid_results = list(all_results.values())
    avg_wr  = round(np.mean([r["win_rate_pct"] for r in valid_results]), 1) if valid_results else 0
    avg_ret = round(np.mean([r["avg_return_pct"] for r in valid_results]), 2) if valid_results else 0

    # Propose deployment with ONLY WFV-valid + RuFlo-ranked stocks
    import threading
    from deployment_manager import propose_deployment_sync
    def _propose():
        try:
            propose_deployment_sync(
                {"per_stock": deployable_params},  # FIX-03: FILTERED
                wfv_results,
                {
                    "avg_win_rate": avg_wr,
                    "avg_return": avg_ret,
                    "stocks_optimized": len(all_results),
                    "stocks_deployable": len(deployable_params),
                    "stocks_overfit": len(overfit_stocks),
                }
            )
        except Exception as e:
            append_log(AUDIT_LOG_FILE, f"PROPOSE ERROR: {e}")
    threading.Thread(target=_propose, daemon=True).start()

    try:
        from workflow_manager import (
            record_optimization_completed,
            record_validation_completed,
            record_decision_engine_ready,
        )
        record_optimization_completed(
            total_symbols=len(symbols),
            optimized_symbols=len(all_results),
            deployable_symbols=len(deployable_params),
            overfit_symbols=len(overfit_stocks),
        )
        record_validation_completed(
            total_symbols=len(wfv_results),
            valid_symbols=sum(1 for r in wfv_results.values() if isinstance(r, dict) and r.get("valid")),
            validity_pct=round((sum(1 for r in wfv_results.values() if isinstance(r, dict) and r.get("valid")) / max(len(wfv_results), 1)) * 100, 1) if wfv_results else 0.0,
        )
        if deployable_params:
            record_decision_engine_ready(
                deployable_symbols=len(deployable_params),
                blocked_symbols=len(overfit_stocks),
                reason="WFV-filtered deployable set prepared for approval",
            )
    except Exception as e:
        append_log(AUDIT_LOG_FILE, f"WORKFLOW MARK ERROR OPTIMIZER END: {e}")

    append_log(AUDIT_LOG_FILE,
               f"OPTIMIZER COMPLETE: {len(all_results)}/{len(symbols)} optimized "
               f"deployable={len(deployable_params)} overfit={len(overfit_stocks)} "
               f"avg_wr={avg_wr}%")
    return output


# ─────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────

def _fetch_data(symbol: str, days: int = 7300) -> pd.DataFrame:
    try:
        from dhan_data import fetch_daily_data
        df = fetch_daily_data(symbol, days=days)
        if df is None or df.empty:
            return None
        return df
    except (ConnectionError, TimeoutError, OSError, ValueError) as e:
        logger.warning(f"fetch_daily_data: Failed for {symbol}: {type(e).__name__}: {e}")
        return None


def get_optimizer_summary() -> str:
    data = load_json(OPTIMIZER_RESULTS_FILE, {})
    if not data:
        return "No optimizer results yet. Run /optimize first."

    results = data.get("results", {})
    if not results:
        return "No valid results found."

    valid  = [r for r in results.values() if r.get("valid")]
    stable = [r for r in valid if r.get("params_stable")]
    deployable = data.get("deployable", len(valid))
    overfit = data.get("overfit", 0)
    avg_wr = round(np.mean([r["win_rate_pct"] for r in valid]), 1) if valid else 0
    avg_pf = round(np.mean([r["profit_factor"] for r in valid]), 2) if valid else 0

    lines = [
        f"Optimizer Results (Optuna + Bayesian + RuFlo)",
        f"Run: {data.get('run_date', 'N/A')[:16]}",
        f"Optimized: {data.get('optimized')}/{data.get('total')}",
        f"Deployable (WFV valid): {deployable}",
        f"Overfit (blocked): {overfit}",
        f"Stable params: {len(stable)}/{len(valid)}",
        f"",
        f"Avg Win Rate: {avg_wr}%",
        f"Avg Profit Factor: {avg_pf}",
        f"",
    ]

    # Show RuFlo ranking if available
    ranking = data.get("ruflo_ranking", [])
    if ranking:
        lines.append("RuFlo Top 5 Ranked Stocks:")
        for r in ranking[:5]:
            lines.append(f"  {r.get('symbol')}: score={r.get('ruflo_score', 0):.2f} "
                        f"rank={r.get('rank', '?')}")
        lines.append("")

    lines.append("Use /deployapprove to deploy")
    lines.append("Use /walkforward for overfit check")

    return "\n".join(lines)
